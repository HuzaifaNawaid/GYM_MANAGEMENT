package Gym_Management;

import java.sql.*;

public class Connectio_Class {

    Connection con;
    Statement stn;

    Connectio_Class() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gym_management", "root", "ranamudassir123");
            stn = con.createStatement();
           
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String s[]) {
        new Connectio_Class();
    }
}
