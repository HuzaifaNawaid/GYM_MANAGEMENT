package Gym_Management;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class GeminiConeection {

    public static String generateContent(String prompt) throws IOException {
        String apiKey = "AIzaSyAsFRXuOTscQ8b6_CrCoj01T1eY76qOh40";

        // Endpoint for Gemini text generation
         String modelName = "text-bison-001";  // Use valid model

    URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + modelName + ":generateText?key=" + apiKey);

        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        // JSON payload as per Gemini text generation API
        String jsonInput = """
        {
          "prompt": {
            "text": "%s"
          },
          "temperature": 0.7,
          "maxTokens": 100
        }
        """.formatted(prompt);

        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = jsonInput.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        int responseCode = conn.getResponseCode();

        if (responseCode == HttpURLConnection.HTTP_OK) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    response.append(line.trim());
                }
                return response.toString();
            }
        } else {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), "utf-8"))) {
                StringBuilder error = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    error.append(line.trim());
                }
                throw new IOException("HTTP error code: " + responseCode + "\nError: " + error.toString());
            }
        }
    }

    public static void main(String[] args) {
        try {
            String prompt = "Explain the benefits of exercise.";

            String response = generateContent(prompt);

            System.out.println("Gemini API text generation response:");
            System.out.println(response);
        } catch (IOException e) {
            System.err.println("Error calling Gemini API:");
            e.printStackTrace();
        }
    }
}
