package Gym_Management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;

public class GeminiFrame extends JFrame {

    private final JTextArea promptArea = new JTextArea(5, 40);
    private final JTextArea responseArea = new JTextArea(10, 40);
    private final JButton sendButton = new JButton("Send to Gemini");

    public GeminiFrame() {
        setTitle("Gemini Text Generation");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        JPanel promptPanel = new JPanel(new BorderLayout());
        promptPanel.setBorder(BorderFactory.createTitledBorder("Enter Prompt"));
        promptPanel.add(new JScrollPane(promptArea), BorderLayout.CENTER);

        JPanel responsePanel = new JPanel(new BorderLayout());
        responsePanel.setBorder(BorderFactory.createTitledBorder("API Response"));
        responseArea.setEditable(false);
        responsePanel.add(new JScrollPane(responseArea), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(sendButton);

        add(promptPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(responsePanel, BorderLayout.SOUTH);

        sendButton.addActionListener(this::onSendButtonClicked);
    }

    private void onSendButtonClicked(ActionEvent e) {
        String promptText = promptArea.getText().trim();
        if (promptText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a prompt.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        sendButton.setEnabled(false);
        responseArea.setText("Waiting for response...");

        new Thread(() -> {
            try {
                String response = GeminiConeection.generateContent(promptText);
                SwingUtilities.invokeLater(() -> responseArea.setText(response));
            } catch (IOException ex) {
                SwingUtilities.invokeLater(() -> {
                    responseArea.setText("Error calling Gemini API:\n" + ex.getMessage());
                    JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "API Error", JOptionPane.ERROR_MESSAGE);
                });
            } finally {
                SwingUtilities.invokeLater(() -> sendButton.setEnabled(true));
            }
        }).start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GeminiFrame frame = new GeminiFrame();
            frame.setVisible(true);
        });
    }
}
