/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Gym_Management;

/**
 *
 * @author MUZAMMIL
 */
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class ListModelsExample {
    public static void listModels(String apiKey) throws IOException {
        URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models?key=" + apiKey);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        int responseCode = conn.getResponseCode();
        InputStream stream = (responseCode == HttpURLConnection.HTTP_OK) ? conn.getInputStream() : conn.getErrorStream();

        try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                response.append(line.trim());
            }
            System.out.println("Available models:");
            System.out.println(response.toString());
        }
    }

    public static void main(String[] args) {
        String apiKey = "AIzaSyAsFRXuOTscQ8b6_CrCoj01T1eY76qOh40";
        try {
            listModels(apiKey);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
