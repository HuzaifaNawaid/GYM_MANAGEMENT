package Gym_Management;

public class MainApp {

    public static void main(String[] args) {
        try {
            // Set Nimbus Look and Feel (looks consistent and modern)
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            // If Nimbus is not available, fall back to system look and feel
            try {
                javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        // Launch the login form (replace with your actual form name)
        javax.swing.SwingUtilities.invokeLater(() -> {
            new Loading_Page().setVisible(true); // Replace LoginForm with your main form class name
        });
    }

}
