
package Gym_Management;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.UUID;

public class TokenManager {
    public static String generateToken(String email) throws SQLException {
        String token = UUID.randomUUID().toString();
        LocalDateTime expiry = LocalDateTime.now().plusMinutes(30);

        Connectio_Class obj = new Connectio_Class();
        String query = "INSERT INTO password_reset_tokens (email, token, expiry) VALUES (?, ?, ?)";
        PreparedStatement pst = obj.con.prepareStatement(query);
        pst.setString(1, email);
        pst.setString(2, token);
        pst.setTimestamp(3, Timestamp.valueOf(expiry));
        pst.executeUpdate();

        return token;
    }

    public static boolean isValidToken(String email, String token) throws SQLException {
        Connectio_Class obj = new Connectio_Class();
        String query = "SELECT * FROM password_reset_tokens WHERE email = ? AND token = ? AND expiry > NOW()";
        PreparedStatement pst = obj.con.prepareStatement(query);
        pst.setString(1, email);
        pst.setString(2, token);
        ResultSet rs = pst.executeQuery();
        return rs.next();
    }
}

